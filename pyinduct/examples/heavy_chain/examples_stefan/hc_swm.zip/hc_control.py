from __future__ import division
from copy import copy
from pickle import dumps, dump
import sympy as sp
from scipy.special import iv, yv, jv
import numpy as np
import pyqtgraph as pg
from pyinduct import register_base, get_base
from pyinduct.core import Function, ComposedFunctionVector
from pyinduct.trajectory import SmoothTransition
from pyinduct.shapefunctions import LagrangeFirstOrder, cure_interval
from pyinduct.control import Controller, ControlLaw
from pyinduct.placeholder import FieldVariable, TemporalDerivedFieldVariable, SpatialDerivedFieldVariable, \
    ScalarTerm
from pyinduct.simulation import SimulationInput, simulate_system, SimulationInputSum, process_sim_data, Domain
from pyinduct.visualization import PgAnimatedPlot, PgSurfacePlot, EvalData
from pyinduct.utils import find_roots

from hc_system import heavy_chain, hc_visualization

__author__ = 'Stefan Ecklebe'

# system params
system_order = 2
load_mass = 1
a_0 = 1e0
rho_0 = 1e0
rho = rho_0 * a_0
gravity = 9.81
chain_length = 1
node_distance = chain_length / 50


def tau(z):
    return gravity * (load_mass + rho * z)


# system definitions
c0 = (0, 0)
c1 = (0, 1)
c2 = (load_mass / tau(0), 0)
c = np.asarray([c0, c1, c2]).T

# control params (desired closed loop properties)
# beta = 1
# beta = .5
beta = 0
approx_order = 10  # must be even
# approx_order = 4  # must be even
lumped_eigvals = (-1, -2)
kappa_2 = 1
# kappa_1 = -lumped_eigvals[0] - lumped_eigvals[1]
# kappa_0 = lumped_eigvals[0] * lumped_eigvals[1]
kappa_1 = 4.0
kappa_0 = 4.0
stiffness = 0
damping = 1
print("(kappa_2, kappa_1, kappa_0) = {0}".format((kappa_2, kappa_1, kappa_0)))

# feedforward params
yd_start = 0
yd_end = 2

# coloring
col_map = pg.ColorMap(np.array([0, .5, 1]),
                      np.array([[0, 0, 1., 1.], [0, 1., 0, 1.], [1., 0, 0, 1.]]))
idxs = np.linspace(0, 1, approx_order)
colors = col_map.map(idxs, mode="qcolor")

# evaluation options
z_start = 0
z_end = chain_length
z_step = .01
spat_domain = Domain(bounds=(z_start, z_end), step=z_step)

t_start = 0
t_end = 3
t_step = 0.01
temp_domain = Domain(bounds=(t_start, t_end), step=t_step)


def calc_w0(a0, rho0, g, ml, der_order):
    """
    returns evaluation handle for w0(z, s) which are the spatial solutions for that occur for exponential time solutions

    :param a0:
    :param rho0:
    :paramg g:
    :param ml:
    :param der_order: spatial derivative order to be provided
    :return:
    """
    z, rho_0, s, a_0, g_, m_l, y0 = sp.symbols("z rho_0, s, A_0, g, m_l, y0")
    rho_ = rho_0 * a_0
    tau_ = g_ * (m_l + rho * z)
    zq = sp.I * 2 * s / g * sp.sqrt(tau_ / rho_)
    dzq = zq.diff(z)
    zq0 = zq.subs(z, 0)
    dzq0 = dzq.subs(z, 0)

    # general solution
    kappa_1, kappa_2 = sp.symbols("kappa_1, kappa_2")
    w0 = kappa_1 * sp.besselj(0, zq) + kappa_2 * sp.bessely(0, zq)

    if 0:
        # use symbolic computation -> seems to produce errors
        bc1 = sp.Eq(w0.subs(z, 0), y0)
        bc2 = sp.Eq(w0.diff(z).subs(z, 0), s ** 2 * y0 / g)
        sol = sp.solve([bc1, bc2], [kappa_1, kappa_2])
        w0_sol = w0.subs([(kappa_1, sol[kappa_1]), (kappa_2, sol[kappa_2])]).simplify()

    else:
        # manual solution, make use of wronsky determinant alpha = 1/detJ
        alpha = -sp.pi * zq0 / 2
        psi = -m_l * s ** 2 / (tau_.subs(z, 0) * dzq0)
        kappa_1q = alpha * (sp.bessely(1, zq0) - psi * sp.bessely(0, zq0))
        kappa_2q = alpha * (-sp.besselj(1, zq0) + psi * sp.besselj(0, zq0))
        w0_sol = w0.subs([(kappa_1, kappa_1q), (kappa_2, kappa_2q)]).simplify()

    # substitute values
    wn = w0_sol.subs([(a_0, a0), (rho_0, rho0), (g_, g), (m_l, ml), (y0, 1)])

    # derive
    wd = []
    for n in range(der_order + 1):
        wd.append(wn.diff(z, n))

    # append derivative of wo and wo' for s
    wd.append(wn.diff(s, 1))
    wd.append(wn.diff(z, 1).diff(s, 1))
    wd.append(wn.diff(s, 1).diff(z, 1))

    # print(wd[1])
    # print()
    # print(wd[3])
    # print()
    # print(wd[4])

    sym2sci = {"besseli": iv, "bessely": yv, "besselj": jv}
    res = []
    for w in wd:
        res.append(sp.lambdify((z, s), w, modules=[sym2sci, "numpy"]))

    return res


def calc_characteristic_time_delays(a0, rho0, g, ml, l):
    """
    calculates the time delays tau_1 = gamma_1(l) and tau_2= -gamma_2(l)
    :param a0:
    :param rho0:
    :param g:
    :param ml:
    :param l:
    :return:
    """

    def gamma(z):
        return 1 / np.sqrt(tau(z)) * (2 * np.sqrt(rho) * z + (2 * load_mass / np.sqrt(rho))) \
               - 2 * load_mass * np.sqrt(1 / (gravity * load_mass)) / np.sqrt(rho)

    tau1 = gamma(l)
    tau2 = - (-1) * gamma(l)

    return tau1, tau2


def calc_cl_eigenvalues(cnt, beta, tau1, tau2):
    """
    calculates the first cnt eigenvalues

    :param cnt:
    :return:
    """
    if cnt % 2 != 0:
        raise ValueError("amount of eigenvalues has to be even!")

    roots = []
    if beta < 0:
        for n in range(-int(cnt / 2), int(cnt / 2) + 1):
            roots.append(1 / (tau1 + tau2) * np.complex(np.log(np.abs(beta)), 2 * n * np.pi))
    elif beta > 0:
        for n in range(-int(cnt / 2) + 1, int(cnt / 2) + 1):
            roots.append(1 / (tau1 + tau2) * np.complex(np.log(np.abs(beta)), (2 * n - 1) * np.pi))

    return roots


def calc_spatial_solutions(a0, rho0, g, ml, l, derivative_order, show=False):
    """
    construct solutions of spatial ode
    :param a0:
    :param rho0:
    :param ml:
    :param g:
    :param l:
    :param derivative_order:
    :param show:
    """
    # get w0(s, z), w0'(s, z) and d/ds * w0 as well as d/ds w0'(s, z)
    w0 = calc_w0(a0=a0, rho0=rho0, g=g, ml=ml, der_order=derivative_order)

    def char_func(s_k):
        """
        characteristic function of the system (homogeneous case) w0'(s, l)
        :param s_k:
        :return:
        """
        out = np.zeros_like(s_k)
        if not out.shape:
            # scalar case
            if np.isclose(np.abs(s_k), 0):
                return 0
            else:
                return w0[1](chain_length, s_k)

        # general case
        s0 = np.isclose(np.abs(s_k), 0)
        s_not_0 = np.logical_not(s0)
        eval_s = s_k[s_not_0]
        out[s_not_0] = w0[1](chain_length, eval_s)
        return out

    def char_func_ds(s_k):
        """
        characteristic function of the system (homogenous case) d/ds w0'(s, l)
        :param s_k:
        :return:
        """
        out = np.zeros_like(s_k)
        if not out.shape:
            if s_k == 0:
                return 0
            else:
                return w0[3](chain_length, s_k)

        s0 = np.isclose(s_k, 0)
        s_not_0 = np.logical_not(s0)
        eval_s = s_k[s_not_0]
        out[s_not_0] = w0[3](chain_length, eval_s)
        return out

    if 0:
        # create data for plots
        limit = 60
        real_range = np.linspace(-5, 5, 1e2)
        im_range = np.linspace(-limit, limit, 1e3)
        aa, bb = np.meshgrid(real_range, im_range)
        cc = aa + 1j * bb
        res = char_func(cc)
        res_ds = char_func_ds(cc)

        # save data
        print("dumping data ..")
        with open("../results/hc_evp.dat", "w") as f:
            f.write(dumps([EvalData([real_range, im_range], res.T),
                           EvalData([real_range, im_range], res_ds.T)
                           ]))
            quit()

        candidates = cc[np.absolute(res) < 1e-2]
        print(candidates)

        # data1 = EvalData([real_range, im_range], np.real(res))
        # data2 = EvalData([real_range, im_range], np.imag(res))
        # data3 = EvalData([real_range, im_range], np.absolute(res))
        # sp1 = SurfacePlot(data1)
        # sp2 = SurfacePlot(data2)
        # sp3 = SurfacePlot(data3)

        # min = 0
        # max = 3
        # vals = np.clip(np.absolute(res), min, max)
        # pg.image(vals)
        #
        # img = col_map.map(vals)
        # pg.image(img)
        # app.exec_()

    if 1:
        # use eigenvalues of w0
        # !! attention this approach does not recognize roots of higher order
        print("using open loop eigenvalues")
        real_range = np.linspace(-0.1, .1, 10)
        imag_range = np.linspace(0, approx_order * 12, 1e3)
        roots = find_roots(char_func, approx_order / 2, [real_range, imag_range], atol=1e-12, complex=True,
                           show_plot=show)
        print("function values: \n{0}".format(np.absolute(char_func(roots))))

        # clean numeric rubbish
        roots = 1j * np.imag(roots)

        # mirror the other half (since roots are symmetrical to Re{} = 0
        eigen_values = np.sort(np.hstack([-roots[1:], roots]))
    else:
        # use eigenvalues from approximated system matrix (should be the same as those from w0)
        with open("./dump.dat", "r") as f:
            vals = eval(f.read()[5:])

        # exclude double eigenvalue at s==0
        eigen_values = sorted(vals, key=lambda x: np.abs(np.imag(x)))[1:approx_order]
        # clean numeric rubbish
        eigen_values = np.sort(1j * np.imag(eigen_values))

    print("eigenvalues:\n{0}".format(eigen_values))

    def w0_factory(handles, s, order):

        def w0_0(z):
            if order == 0:
                return np.ones_like(z) * (1 + 0j)
            else:
                return np.zeros_like(z) * (1 + 0j)

        def w(z):
            return handles[order](z, s)

        if np.isclose(s, 0, atol=1e-3):
            # exception for eigen value s=0 because of singularity in besselfunctions
            return w0_0
        return w

    all_handles = []
    for der_order in range(derivative_order + 1):
        all_handles.append([w0_factory(w0, s, der_order) for s in eigen_values])

    # create extra handle for function vector of double eigenvalues
    def extra_factory(handle, s, order):
        def extra_func0(z):
            if order == 0:
                if isinstance(z, np.ndarray):
                    return np.ones_like(z)
                else:
                    return 1
            else:
                if isinstance(z, np.ndarray):
                    return np.zeros_like(z)
                else:
                    return 0

        def extra_func(z):
            return handle(s, z)

        if np.isclose(s, 0, atol=1e-3):
            return extra_func0
        return extra_func

    extra_functions = [Function(extra_factory(w0[derivative_order + 1 + order], 0, order), domain=(0, l))
                       for order in range(2)]

    handle_mat = np.array(all_handles)

    all_w0_funcs = []
    for col in handle_mat.T:
        all_w0_funcs.append(Function(col[0], domain=(0, l), derivative_handles=col[1:]))

    if show:
        # debug prints
        # TODO update to python 3.5 to make this work
        # dbg_vals = np.linspace(*spat_domain.bounds, 1000)
        dbg_vals = np.array(spat_domain)
        pwins = {}
        for der in range(derivative_order + 1):
            pwins[der] = pg.plot(title="w0d{}".format(der))
            for idx, func in enumerate(all_w0_funcs):
                pwins[der].plot(dbg_vals, np.real(func.derive(der)(dbg_vals)),
                                pen=pg.mkPen(color=colors[idx]))
                pwins[der].plot(dbg_vals, np.imag(func.derive(der)(dbg_vals)),
                                pen=pg.mkPen(color=colors[idx], style=pg.QtCore.Qt.DashLine))

        pwins["extra"] = pg.plot(title="w0x")
        for ef in extra_functions:
            pwins["extra"].plot(dbg_vals, np.real(ef(dbg_vals)),
                                pen=pg.mkPen(color=colors[-1]))
            pwins["extra"].plot(dbg_vals, np.imag(ef(dbg_vals)),
                                pen=pg.mkPen(color=colors[-1], style=pg.QtCore.Qt.DashLine))
        pg.QtCore.QCoreApplication.exec_()

    # return np.array([normalize_function(func) for func in all_w0_funcs]), eigen_values
    return all_w0_funcs, eigen_values, extra_functions


class HCStateVector(ComposedFunctionVector):
    """
    vector that represents the state of the heavy chain, containing (w'(z, t), w.(z, t), w(0, t), w.(0, t)) at t=0
    """

    def __init__(self, functions, scalars, origin_label):
        if len(functions) != 2 or len(scalars) != 2:
            raise TypeError("wrong dimensions!")

        ComposedFunctionVector.__init__(self, functions, scalars)
        self.orig_lbl = origin_label

    @property
    def funcs(self):
        return self.members["funcs"]

    @property
    def scalars(self):
        return self.members["scalars"]

    def transformation_hint(self, info, target):
        """
        returns ready to use handle for weight transformation from pure Function Base, otherwise super method is
        returned
        """
        if target is False:
            raise NotImplementedError

        if target and isinstance(info.src_base[0], Function):
            if info.dst_order > info.src_order - 1:
                return None, None

            if info.src_lbl == self.orig_lbl:
                return self._transform_from_functions_factory(info), None
            else:
                # create transform from someone who knows how to convert
                name = info.src_lbl + "_state"
                # from current src to assistant system
                assistant_info = copy(info)
                assistant_info.dst_lbl = name
                assistant_info.dst_base = get_base(name, 0)
                assistant_info.dst_order = info.dst_order

                # from assistant system to dst
                target_info = copy(info)
                target_info.src_lbl = name
                target_info.src_base = get_base(name, 0)
                target_info.src_order = info.dst_order

                super_handle, super_hint = super(HCStateVector, self).transformation_hint(target_info, True)
                return super_handle, assistant_info

        # fallback method of super class
        return super(HCStateVector, self).transformation_hint(info, target)

    @staticmethod
    def _transform_from_functions_factory(info):
        """
        calculates transformation that converts weights from src to dst basis
        """
        src_dim = info.src_base.size
        dst_dim = info.dst_base.size

        if dst_dim % 2 != 0:
            return None

        mat = np.zeros((dst_dim * (info.dst_order + 1), src_dim * (info.src_order + 1)))

        # generate core of mapping
        core = np.zeros((dst_dim, 2 * src_dim))
        for i in range(src_dim):
            core[2 * i, i] = 1
            core[2 * i - 1, i + src_dim] = 1

        # fill with copies until needed order is accomplished
        for o in range(info.dst_order + 1):
            mat[o * dst_dim:(1 + o) * dst_dim, o * 2 * src_dim:(1 + o) * 2 * src_dim] = core

        def handle(weights):
            return np.dot(mat, weights)

        return handle

    def scale(self, factor):
        return HCStateVector(np.array([func.scale(factor) for func in self.members["funcs"]]),
                             np.array([scal * factor for scal in self.members["scalars"]]),
                             self.orig_lbl)


def create_function_vectors(label, eig_vals=None, zero_padding=False):
    """
    builds a complete set (basis) of function vectors, length will be 2 times the length of the input

    :param label: label of function set that forms the basis of the state approximation
    :param eig_vals: eigenvalues, corresponding to the shapefunctions described by label
    :param zero_padding: perform padding with zeros to construct function vector from simulation shapefunctions
    :return:
    """
    entries = []
    funcs = get_base(label, 0)
    funcs_dz = get_base(label, 1)
    zero_func = Function(lambda z: 0, nonzero=(0, 0))
    for idx, (func, func_dz) in enumerate(zip(funcs, funcs_dz)):
        if zero_padding:
            entries.append(HCStateVector(functions=(func_dz, zero_func), scalars=(func(0), 0), origin_label=label))
            entries.append(HCStateVector(functions=(zero_func, func), scalars=(0, func(0)), origin_label=label))
        else:
            entries.append(HCStateVector(functions=(func_dz, func.scale(eig_vals[idx])),
                                         scalars=(func(0), eig_vals[idx] * func(0)),
                                         origin_label=label))

            # construct extra function vector for double eigenvalue at s=0
            if np.isclose(eig_vals[idx], 0, atol=1e-3):
                # TODO verify what is correct in the end (probably both will deliver the same result)
                if 1:
                    # derive only 2nd part of state vector
                    entries.append(HCStateVector(functions=(zero_func, func),
                                                 scalars=(0, func(0)),
                                                 origin_label=label))
                else:
                    # derive whole state vector
                    # TODO calculate lim(d/ds w=(s, z)) for s->0
                    entries.append(HCStateVector(functions=(extra_funcs[1], func),
                                                 scalars=(extra_funcs[0](0), func(0)),
                                                 origin_label=label))

    return entries


def calc_flat_functions(spatial_funcs, eigen_values, restriction, derivative_order, show=False):
    """
    since y is already a part of the state x, just use it!
    :param spatial_funcs: initial state values for exponential temporal solutions
    :param eigen_values: eigenvalues that correspond to the spatial_funcs
    :param restriction: pseudo time span where approximation holds
    :param derivative_order: required spatial order of provided functions
    :param show: plot the generated functions and their derivatives
    :return:
    """

    def f_func_factory(spat_func, s, order):
        y0 = 1
        assert np.allclose(spat_func(0), y0)

        def extra_func(z):
            # extra func, gained by deriving orig_func for s
            if order == 0:
                return spat_func(0) * z
                # return spat_func(0)*z*np.exp(s*z)
            elif order == 1:
                return spat_func(0) * np.ones_like(z)
                # return spat_func(0)*(np.exp(s*z) + s*z**2*np.exp(s*z))
            elif order == 2:
                return np.zeros_like(z) * (1 + 0j)
                # return spat_func(0)*(s*np.exp(s*z) + 2*s*z*np.exp(s*z) + s**2*z**3*np.exp(s*z))
            else:
                raise NotImplementedError

        def orig_func(z):
            return spat_func(0) * np.power(s, order) * np.exp(s * z)

        if np.isclose(s, 0, atol=1e-3):
            return [orig_func, extra_func]
        return [orig_func]

    f_handles = []
    for order in range(derivative_order + 1):
        f_handles.append(sum([f_func_factory(func, s, order) for func, s in zip(spatial_funcs, eigen_values)], []))

    handle_mat = np.array(f_handles)
    y_funcs = []
    for col in handle_mat.T:
        y_funcs.append(Function(col[0], domain=restriction, derivative_handles=col[1:]))

    # y_funcs = np.array([Function(func[0], derivative_handles=func[1:], domain=restriction) for func in f_funcs])

    if show:
        # debug prints
        pwins = {}
        values = np.linspace(restriction[0], restriction[1], 1e3)
        for der in range(derivative_order + 1):
            pwins[der] = pg.plot(title="y0_d{}".format(der))
            for idx, func in enumerate(y_funcs):
                pwins[der].plot(values, np.real(func.derive(der)(values)),
                                pen=pg.mkPen(color=colors[idx]))
                pwins[der].plot(values, np.imag(func.derive(der)(values)),
                                pen=pg.mkPen(color=colors[idx], style=pg.QtCore.Qt.DashLine))

        pg.QtCore.QCoreApplication.exec_()

    # return np.array([normalize_function(func) for func in y_funcs])
    return y_funcs


def hc_b_i(idx):
    """
    boundary term vectors
    :param idx: desired index
    :return:
    """
    if idx == 1:
        return np.array([[tau(chain_length)], [0]])
    elif idx == 2:
        return np.array([[stiffness], [damping]])
    else:
        raise NotImplementedError


def hc_lambda_i(idx, z):
    """
    eigenvalues of the pde system
    :param idx:
    :param z:
    :return:
    """
    ev = np.sqrt(rho / tau(z))
    if idx == 1:
        # return -ev
        return ev
    elif idx == 2:
        # return ev
        return -ev
    else:
        raise NotImplementedError


def hc_r_i(idx, z):
    """
    right eigenvectors of the pde system (cols of T)
    :param idx:
    :param z:
    :return:
    """
    if idx == 1 or idx == 2:
        return np.array([[hc_lambda_i(idx, z)],
                         [-1]])
    else:
        raise NotImplementedError


def hc_l_i(idx, z):
    """
    left eigenvectors of the pde system (cols of T^-1)
    :param idx:
    :param z:
    :return:
    """
    if idx == 1 or idx == 2:
        return np.array([[1 / (2 * hc_lambda_i(idx, z)), -1 / 2]]).T
    else:
        raise NotImplementedError


def hc_mu(z):
    return -rho * gravity / (4 * tau(z))


def hc_nu(z):
    return rho * gravity / (4 * tau(z))


def calc_m_matrix(z):
    m = np.hstack([calc_m_vector(1, z), calc_m_vector(2, z)])
    return m


def calc_m_vector(idx, z):
    if idx == 1 or idx == 2:
        e_term = np.power(load_mass / (load_mass + rho * z), .25)
        m_i = e_term * np.dot(np.dot(hc_r_i(idx, z), hc_l_i(idx, 0).T), np.atleast_2d(c[:, system_order]).T)
        return m_i
    else:
        raise NotImplementedError


def calc_kd():
    return np.array([[kappa_2 * beta], [kappa_2]])


def calc_scalings():
    """
    calculates the scaling factors alpha and sigma which are used to eliminate unwanted terms in the control law
    :return: alpha, sigma
    """
    b1 = hc_b_i(1)
    b2 = hc_b_i(2)
    kd = calc_kd()
    m1 = calc_m_vector(1, chain_length)
    m2 = calc_m_vector(2, chain_length)

    a_mat = np.array([[kappa_2 * beta, damping * m1[1, 0]],
                      [kappa_2, damping * m2[1, 0]]])
    b_vec = tau(chain_length) * np.array([[m1[0, 0]],
                                          [m2[0, 0]]])
    alpha, sigma = np.dot(np.linalg.inv(a_mat), b_vec)

    # test solution
    m = calc_m_matrix(chain_length)
    res = np.dot(b1.T, m) - alpha*kd.T - sigma*np.dot(b2.T, m)
    print("residual: {0}".format(res))

    return alpha, sigma


class HCFeedForward(SimulationInput):
    """
    Feed forward for the closed loop
    """

    def __init__(self, delays, alpha, y0, y1, dt):
        SimulationInput.__init__(self, "FeedForward")
        self._tau1, self._tau2 = delays
        self._alpha = alpha
        self._traj_gen = SmoothTransition((y0, y1), (-delays[0], -delays[0] + dt), method="poly", differential_order=2)

    def _calc_output(self, **kwargs):
        t = kwargs["time"]
        # store desired trajectory
        yd = self._value_storage.get("yd", [])
        yd.append(self._traj_gen(t))
        self._value_storage["yd"] = yd

        # calculate input
        yt1 = self._traj_gen(t + self._tau1)
        yt2 = self._traj_gen(t + self._tau2)
        f = kappa_2 * (yt2[2] + beta * yt1[2]) \
            + kappa_1 * (yt2[1] + beta * yt1[1]) \
            + kappa_0 * (yt2[0] + beta * yt1[0])
        return dict(output=self._alpha * f)


def main():
    #  ----------------------------------- System related ------------------------------------
    # initial conditions
    def w_func(z, t):
        """
        initial conditions for testing
        """
        return 0
        # return 0.2
        # return (chain_length-z)*.1

    def w_dt_func(z, t):
        """
        initial conditions for testing
        """
        # return np.sin(z) + t
        # return 1*z
        return 0

    ic = np.array([
        Function(lambda z: w_func(z, 0)),
        Function(lambda z: w_dt_func(z, 0)),
    ])

    # sim funcs
    nodes, funcs = cure_interval(LagrangeFirstOrder, spat_domain.bounds, node_distance=node_distance)
    register_base("sim_funcs", funcs)

    #  ----------------------------------- Control related ------------------------------------

    # ----------- calculate shape functions -----------
    # delays
    tau_1, tau_2 = calc_characteristic_time_delays(a0=a_0, rho0=rho_0, g=gravity, ml=load_mass, l=chain_length)
    print("time delays:\n{0}, {1}".format(tau_1, tau_2))

    # functions themselves
    w0_k, eig_values, extra_funcs = calc_spatial_solutions(a0=a_0, rho0=rho_0, g=gravity, ml=load_mass, l=chain_length,
                                                           derivative_order=1, show=False)
    register_base("exp_solution_funcs", w0_k)

    # reinterpret shape functions as state vectors
    sim_vectors = create_function_vectors("sim_funcs", zero_padding=True)
    register_base("sim_funcs_state", sim_vectors)

    # use exp solutions to construct state vectors
    exp_vectors = create_function_vectors("exp_solution_funcs", eig_vals=eig_values)
    register_base("exp_solution_funcs_state", exp_vectors)

    # extract cont. members of state for easier usage
    omega_funcs = np.array([vec.funcs for vec in exp_vectors])
    register_base("omega_funcs_1", omega_funcs[:, 0])
    register_base("omega_funcs_2", omega_funcs[:, 1])

    # create shape function of flat output
    flat_funcs = calc_flat_functions(w0_k, eig_values, (-tau_1, tau_2), derivative_order=2, show=False)
    register_base("flat_funcs", flat_funcs)

    # ----------- calculate control law -----------
    alpha, sigma = calc_scalings()
    print("calculated alpha = {}".format(alpha))
    print("calculated sigma = {}".format(sigma))

    # ----------- control law  -----------
    b1 = hc_b_i(1)
    b2 = hc_b_i(2)
    b = b1 - sigma * b2
    print("b1 vector:\n{}".format(b1))
    print("b2 vector:\n{}".format(b2))
    print("b vector:\n{}".format(b))

    # term: sigma* b2^T * w(l)
    coll_part_1 = [ScalarTerm(SpatialDerivedFieldVariable("sim_funcs", order=1, location=chain_length),
                              scale=np.asscalar(sigma * b2[0]))]
    coll_part_2 = [ScalarTerm(TemporalDerivedFieldVariable("sim_funcs", order=1, location=chain_length),
                              scale=np.asscalar(sigma * b2[1]))]

    # term: b*omega(l)
    mixed_part_1 = [ScalarTerm(FieldVariable("omega_funcs_1", weight_label="exp_solution_funcs_state", order=(0, 0),
                                             location=chain_length),
                               scale=np.asscalar(b[0]))]
    mixed_part_2 = [ScalarTerm(FieldVariable("omega_funcs_2", weight_label="exp_solution_funcs_state", order=(0, 0),
                                             location=chain_length),
                               scale=np.asscalar(b[1]))]

    # term:  -b*M(l)*eta_hat
    m = calc_m_matrix(chain_length)
    p = -np.dot(b.T, m)

    print("M Matrix at z=l:\n{}".format(m))
    print("p vector:\n{}".format(p))
    flat_part_1 = [ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=system_order,
                                                          weight_label="exp_solution_funcs_state", location=-tau_1),
                              scale=p[0][0]),
                   ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=system_order,
                                                          weight_label="exp_solution_funcs_state", location=tau_2),
                              scale=p[0][1]),
                   ]

    # term -alpha*Udc*eta_bar
    flat_part_2 = [ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=0,
                                                          weight_label="exp_solution_funcs_state", location=-tau_1),
                              scale=-np.asscalar(alpha * kappa_0 * beta)),
                   ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=0,
                                                          weight_label="exp_solution_funcs_state", location=tau_2),
                              scale=-np.asscalar(alpha * kappa_0)),
                   ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=1,
                                                          weight_label="exp_solution_funcs_state", location=-tau_1),
                              scale=-np.asscalar(alpha * kappa_1 * beta)),
                   ScalarTerm(SpatialDerivedFieldVariable("flat_funcs", order=1,
                                                          weight_label="exp_solution_funcs_state", location=tau_2),
                              scale=-np.asscalar(alpha * kappa_1)),
                   ]

    controllers = [
        Controller(ControlLaw(coll_part_1 + coll_part_2 + mixed_part_1 + mixed_part_2 + flat_part_1 + flat_part_2,
                              name="hc_control")),
        # Controller(ControlLaw(coll_part_1, name="collocated_dz")),
        # Controller(ControlLaw(coll_part_2, name="collocated_dt")),
        # Controller(ControlLaw(mixed_part_1, name="omega_dz")),
        # Controller(ControlLaw(mixed_part_2, name="omega_dt")),
        # Controller(ControlLaw(flat_part_1, name="flat_1")),
        # Controller(ControlLaw(flat_part_2, name="flat_2")),
    ]
    ff = HCFeedForward((-tau_1, tau_2), alpha, yd_start, yd_end, 1.5)
    u = SimulationInputSum(controllers + [ff])

    chain_pde = heavy_chain("sim_funcs", input_handle=u,
                            l=chain_length, ml=load_mass, g=gravity, rho=rho)

    # simulate system
    eval_data = simulate_system(chain_pde, ic, temp_domain, spat_domain, der_orders=(1, 1))

    # gather data
    print("collecting data")
    control_data = []
    for cont in controllers:
        control_data.append(cont.get_results(eval_data[0].input_data[0], as_eval_data=True))

    # reconstruct flat output from weights and funcs
    flat_weights = None
    for cont in controllers:
        try:
            flat_weights = cont.get_results(eval_data[0].input_data[0],
                                            result_key="exp_solution_funcs_state")
            break
        except:
            continue

    ff_data = ff.get_results(eval_data[0].input_data[0], as_eval_data=True)
    yd_values = ff.get_results(eval_data[0].input_data[0], result_key="yd")
    yd_data = EvalData([eval_data[0].input_data[0], [0, 1, 2]], yd_values)

    pseudo_time_domain = Domain(bounds=(-tau_1, tau_2), step=1e-3)
    if flat_weights is not None:
        flat_data = process_sim_data("flat_funcs", flat_weights, eval_data[0].input_data[0], pseudo_time_domain, 0, 2,
                                     name="flat_approx")
        omega_data_1 = process_sim_data("omega_funcs_1", flat_weights, eval_data[0].input_data[0], spat_domain,
                                        0, 0, name="w_dz_approx")
        omega_data_2 = process_sim_data("omega_funcs_2", flat_weights, eval_data[0].input_data[0], spat_domain,
                                        0, 0, name="w_dt_approx")

    # display results
    app = pg.QtGui.QApplication([])

    # "rendered" plot
    display_data = hc_visualization(eval_data, nodes)

    if 1:
        plot_win = pg.plot(title="control output")
        plot_win.showGrid(x=True, y=True, alpha=0.5)
        plot_win.addLegend()

        plot_win.plot(np.array(eval_data[0].input_data[0]), yd_values[:, 0], name="yd(t)", pen=pg.mkPen("c"))
        plot_win.plot(np.array(eval_data[0].input_data[0]), eval_data[0].output_data[:, 0], name="y(t)", pen=pg.mkPen("y"))
        plot_win.plot(np.array(ff_data.input_data[0]), ff_data.output_data, name="u_ff(t)", pen=pg.mkPen("m"))

        for idx, ed in enumerate(control_data):
            plot_win.plot(np.array(ed.input_data[0]), ed.output_data, name=ed.name, pen=colors[idx % 2])

        # pt2 = PgAnimatedPlot(eval_data + flat_data, title="debug view", dt=1e-2)
        pt2 = PgAnimatedPlot(eval_data +
                             flat_data +
                             omega_data_1 +
                             omega_data_2,
                             title="debug view")  # , dt=1e-3)

        app.exec_()

    if 0:
        # dump results
        print("dumping data ...")
        data = {"system": eval_data,
                "flat_funcs": flat_data,
                "display": display_data,
                "desired": yd_data,
                "feedforward": ff_data,
                "control": control_data
                }
        with open("../results/hc_control_ie.dat", "wb") as f:
            dump(data, f)


if __name__ == "__main__":
    main()
