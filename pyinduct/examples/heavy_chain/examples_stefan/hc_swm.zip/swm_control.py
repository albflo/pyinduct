from __future__ import division
from PyQt5.QtWidgets import QApplication
from pickle import dump
import numpy as np
import pyqtgraph as pg
import pyqtgraph.opengl as gl

from pyinduct import register_base
from pyinduct.core import Function
from pyinduct.shapefunctions import LagrangeFirstOrder, cure_interval
import pyinduct.simulation as sim
import pyinduct.placeholder as ph
import pyinduct.control as ct
import pyinduct.trajectory as tj
from pyinduct.visualization import EvalData, PgAnimatedPlot, PgSurfacePlot
from pyinduct.utils import Parameters

from swm_eigenproblem import calc_eigenfunctions

__author__ = 'Stefan Ecklebe'

paper_params = False
use_feedforward = True

# simulation parameters
z_start = 0
z_end = 1
z_step = .01

t_start = 0
t_end = 10
t_step = .1
transition_time = 2


def x(z, t):
    """
    initial conditions for testing
    """
    # return np.cos(z)
    return 0


def x_dt(z, t):
    """
    initial conditions for testing
    """
    # return np.sin(z) + t
    return 0


if paper_params:
    # model
    m = 0.5
    sigma = 1.0
    tau = 1.0
    model_modal_approx = True
    model_order = 10
    # controller
    alpha = .5
    beta = 0.1
    k0 = 1
    k1 = 2
    controller_modal_approx = True
    control_order = 5
else:
    # model
    m = 1.0
    sigma = 1.0
    tau = 1.0
    params = Parameters()
    params.m = m
    params.sigma = sigma
    params.tau = tau
    model_modal_approx = False
    model_order = 10
    model_node_distance = 0.05
    # controller
    alpha = 0
    beta = 0.1
    k = 4
    k0 = k * 1.0
    k1 = k * 1.0
    controller_modal_approx = True
    control_order = 10
    controller_node_distance = 0.1


class SimpleController(sim.SimulationInput):
    def __init__(self):
        sim.SimulationInput.__init__(self)

    def _calc_output(self, **kwargs):
        weights = kwargs["weights"]
        return -(1 - alpha) / (1 + alpha) * weights[-1] - beta * weights[len(weights) / 2]


class SimpleFeedForward(sim.SimulationInput):
    def __init__(self, desired_handle):
        sim.SimulationInput.__init__(self)
        self._y = desired_handle

    def _calc_output(self, **kwargs):
        y_p_tau = self._y(kwargs["time"] + 1 * tau)
        y_m_tau = self._y(kwargs["time"] - 1 * tau)
        f = + k0 * (y_p_tau[0] + alpha * y_m_tau[0]) \
            + k1 * (y_p_tau[1] + alpha * y_m_tau[1]) \
            + 1 * (y_p_tau[2] + alpha * y_m_tau[2])
        return dict(output=m / (1 + alpha) * f)


def main():
    app = QApplication([])

    # general
    dt = sim.Domain(bounds=(t_start, t_end), step=t_step)
    dz = sim.Domain(bounds=(z_start, z_end), step=z_step)

    # get approximation functions
    if model_modal_approx or controller_modal_approx:
        _, eig_funcs = calc_eigenfunctions(params, max(control_order, model_order), dz)
    if model_modal_approx:
        model_funcs = model_eig_funcs = eig_funcs[:model_order]
    else:
        model_nodes, model_lag_funcs = cure_interval(LagrangeFirstOrder, dz.bounds, node_distance=model_node_distance)
        model_funcs = model_lag_funcs
    register_base("model_funcs", model_funcs)

    if controller_modal_approx:
        control_funcs = eig_funcs[:control_order]
    else:
        controller_nodes, controller_lag_funcs = cure_interval(LagrangeFirstOrder, dz.bounds,
                                                               node_distance=controller_node_distance)
        control_funcs = controller_lag_funcs
    register_base("control_funcs", control_funcs)

    # construct trajectory
    trajectory_generator = tj.SmoothTransition((0, 1), (tau, tau + transition_time),
                                               method="poly", differential_order=2)

    # construct feed-forward
    feed_forward = SimpleFeedForward(trajectory_generator)

    # debug data for feed-forward
    a = []
    b = []
    for val in dt:
        a.append(trajectory_generator(val))
        b.append(feed_forward(time=val))
    trajectory_values = np.vstack(a)
    feedforward_values = np.array(b)
    trajectory_data = EvalData([np.array(dt), [0, 1, 2]], trajectory_values, name="trajectory")
    feedforward_data = EvalData([np.array(dt)], feedforward_values, name="feedforward")

    if 0:
        # debug plots
        ff_plot = pg.plot(dt, feedforward_values, title="feed-forward output")

        yd_dt_numeric = np.diff(trajectory_values[:, 0], 1) / t_step
        yd_ddt_numeric = np.diff(trajectory_values[:, 0], 2) / t_step ** 2

        trajectory_win = pg.plot(title="trajectories")
        trajectory_win.addLegend()
        yd_plot = trajectory_win.plot(dt, trajectory_values[:, 0], name="yd", pen="c")
        yd_dt_plot = trajectory_win.plot(dt[:-1], yd_dt_numeric, name="yd_dt num", pen="y")
        yd_dt_plot_ = trajectory_win.plot(dt, trajectory_values[:, 1], name="yd_dt_ana", pen="m")
        yd_ddt_plot = trajectory_win.plot(dt[:-2], yd_ddt_numeric, name="yd_ddt_num", pen="b")
        yd_ddt_plot_ = trajectory_win.plot(dt, trajectory_values[:, 2], name="yd_ddt_ana", pen="r")

        app.exec_()
        quit()

    # construct controller

    # use Simulation basis functions for collocated terms
    fieldvar_at0 = ph.FieldVariable("model_funcs", location=0)
    fieldvar_at1 = ph.FieldVariable("model_funcs", location=1)
    fieldvar_dt_at0 = ph.TemporalDerivedFieldVariable("model_funcs", order=1, location=0)
    fieldvar_dt_at1 = ph.TemporalDerivedFieldVariable("model_funcs", order=1, location=1)

    scalar_scale1 = -(1 - alpha) / (1 + alpha)
    scalar_term1 = ph.ScalarTerm(fieldvar_dt_at1, scale=scalar_scale1)

    scalar_scale2 = 1 / (1 + alpha) * np.exp(-tau * sigma / m) * (sigma * tau * (1 - alpha) - m * k1 * (1 + alpha))
    scalar_term2 = ph.ScalarTerm(fieldvar_dt_at0, scale=scalar_scale2)

    scalar_scale3 = -m * k0
    scalar_term3 = ph.ScalarTerm(fieldvar_at0, scale=scalar_scale3)

    scalar_scale4 = -m * k0 / (1 + alpha) * m / (sigma * tau) * (1 - alpha + (alpha - 1) * np.exp(-sigma * tau / m))
    scalar_term4 = ph.ScalarTerm(fieldvar_dt_at0, scale=scalar_scale4)

    scalar_term5 = ph.ScalarTerm(fieldvar_at1, scale=-beta)

    # use Controller specific basis functions for continuous terms
    # this code is a little verbose, but its easier to debug like that
    fieldvar_dz = ph.SpatialDerivedFieldVariable("control_funcs", order=1)
    fieldvar_dt = ph.TemporalDerivedFieldVariable("control_funcs", order=1)
    # I Term
    scalar_func_dz = Function(lambda z: 1 + alpha - (1 + alpha) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    scalar_func_dt = Function(lambda z: 1 - alpha + (alpha - 1) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    register_base("scalar_func_dz", scalar_func_dz)
    register_base("scalar_func_dt", scalar_func_dt)
    int_arg1 = ph.Product(ph.ScalarFunction("scalar_func_dz"), fieldvar_dz)
    int_arg2 = ph.Product(ph.ScalarFunction("scalar_func_dt"), fieldvar_dt)

    # Idz term 1: - gamma = -alpha
    scalar_func_dz_term_dz1 = Function(lambda z: (1 + alpha) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    scalar_func_dt_term_dz1 = Function(lambda z: (1 - alpha) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    register_base("scalar_func_dz_term_dz1", scalar_func_dz_term_dz1)
    register_base("scalar_func_dt_term_dz1", scalar_func_dt_term_dz1)
    int_dz1_arg1 = ph.Product(ph.ScalarFunction("scalar_func_dz_term_dz1"), fieldvar_dz)
    int_dz1_arg2 = ph.Product(ph.ScalarFunction("scalar_func_dt_term_dz1"), fieldvar_dt)

    # Idz term 2: - gamma = alpha
    scalar_func_dz_term_dz2 = Function(lambda z: (1 - alpha) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    scalar_func_dt_term_dz2 = Function(lambda z: (1 + alpha) * np.exp((z - 1) * tau * sigma / m), domain=(0, 1))
    register_base("scalar_func_dz_term_dz2", scalar_func_dz_term_dz2)
    register_base("scalar_func_dt_term_dz2", scalar_func_dt_term_dz2)
    int_dz2_arg1 = ph.Product(ph.ScalarFunction("scalar_func_dz_term_dz2"), fieldvar_dz)
    int_dz2_arg2 = ph.Product(ph.ScalarFunction("scalar_func_dt_term_dz2"), fieldvar_dt)

    int_scale1 = 1 / (1 + alpha) * (sigma * tau) ** 2 / m
    int_term11 = ph.IntegralTerm(int_dz1_arg1, dz.bounds, int_scale1)
    int_term12 = ph.IntegralTerm(int_dz1_arg2, dz.bounds, int_scale1)
    int_term1 = [int_term11, int_term12]

    int_scale2 = -1 / (1 + alpha) * sigma * tau * k1
    int_term21 = ph.IntegralTerm(int_dz2_arg1, dz.bounds, int_scale2)
    int_term22 = ph.IntegralTerm(int_dz2_arg2, dz.bounds, int_scale2)
    int_term2 = [int_term21, int_term22]

    int_scale3 = -m * k0 / (1 + alpha)
    int_term31 = ph.IntegralTerm(int_arg1, dz.bounds, int_scale3)
    int_term32 = ph.IntegralTerm(int_arg2, dz.bounds, int_scale3)
    int_term3 = [int_term31, int_term32]

    # complete flat control law and energy based controller as comparison
    flat_law = ct.ControlLaw([scalar_term1, scalar_term2, scalar_term3, scalar_term4] + int_term1 + int_term2 +
                             int_term3, name="flat-law")
    energy_law = ct.ControlLaw([scalar_term1, scalar_term5], name="energy")

    controller = ct.Controller(flat_law)
    mixer = sim.SimulationInputSum([feed_forward if use_feedforward else None, controller])

    # initial conditions
    ic = np.array([
        Function(lambda z: x(z, 0)),  # x(z, 0)
        Function(lambda z: x_dt(z, 0)),  # dx_dt(z, 0)
    ])

    # weak form of the model equations
    core_terms = [ph.IntegralTerm(ph.Product(ph.TemporalDerivedFieldVariable("model_funcs", order=2),
                                             ph.TestFunction("model_funcs")), dz.bounds, scale=sigma * tau ** 2),
                  ph.ScalarTerm(ph.Product(ph.TemporalDerivedFieldVariable("model_funcs", order=2, location=0),
                                           ph.TestFunction("model_funcs", location=0)), scale=m),
                  ph.IntegralTerm(ph.Product(ph.SpatialDerivedFieldVariable("model_funcs", order=1),
                                             ph.TestFunction("model_funcs", order=1)), dz.bounds, scale=sigma)]
    control_term = ph.ScalarTerm(ph.Product(ph.Input(mixer), ph.TestFunction("model_funcs", location=1)), scale=-sigma)

    swm_feedback_pde = sim.WeakFormulation(core_terms + [control_term], name="swm_flat_feedback_{0}_approx".format(
        "mod" if controller_modal_approx else "fem"))

    # simulate system
    data = sim.simulate_system(swm_feedback_pde, ic, dt, dz)
    control_data = controller.get_results(data[0].input_data[0])

    if 0:
        # save data
        print("dumping data ..")
        with open("../results/swm_control.dat", "wb") as f:
            dump(data + [feedforward_data, trajectory_data, control_data], f)

    sf1 = PgSurfacePlot(data[0])
    pt1 = PgAnimatedPlot(data[0])

    # TODO move simple plot into pyinduct.vis
    colors = ["r", "g", "b", "c", "m", "y", "k", "w"]
    plot_win = pg.plot(title="mass position comparison")
    plot_win.showGrid(x=True, y=True, alpha=0.5)
    plot_win.addLegend()
    plot_win.plot(np.array(data[0].input_data[0]), data[0].output_data[:, 0], pen=colors[0], name=data[0].name)
    plot_win.plot(np.array(data[0].input_data[0]), data[0].output_data[:, 0] - trajectory_values[:, 0],
                  pen=pg.mkPen(colors[0], style=pg.QtCore.Qt.DashLine),
                  name="control error")
    plot_win.plot(feedforward_data.input_data[0], feedforward_data.output_data, pen=pg.mkPen(colors[1]),
                  name=feedforward_data.name)
    plot_win.plot(trajectory_data.input_data[0], trajectory_values[:, 0], name="trajectory")

    app.exec_()


if __name__ == "__main__":
    main()
