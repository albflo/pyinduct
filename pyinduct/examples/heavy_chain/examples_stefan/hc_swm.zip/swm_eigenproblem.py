from __future__ import division
from pickle import dump

import numpy as np
from PyQt5.QtWidgets import QApplication
import pyqtgraph as pg
from pyinduct.core import (ComposedFunctionVector, Function,
                           normalize_function, dot_product_l2)
from pyinduct.utils import find_roots

__author__ = 'Stefan Ecklebe'

dump_data = False
display_data = False


def calc_eigenfunctions(params, order, spat_domain):

        mass = params.m
        tau = params.tau
        sigma = params.sigma

        def char_eq(w):
            return w*(np.sin(w) + mass/(sigma*tau**2)*w*np.cos(w))

        def phi_k_factory(freq, derivative_order=0):
            def eig_func(z):
                return np.cos(freq*z) - mass/(sigma*tau**2)*freq*np.sin(freq*z)

            def eig_func_dz(z):
                return -freq*(np.sin(freq*z) + mass/(sigma*tau**2)*freq*np.cos(freq*z))

            def eig_func_ddz(z):
                return freq**2*(-np.cos(freq*z) + mass/(sigma*tau**2)*freq*np.sin(freq*z))

            if derivative_order == 0:
                return eig_func
            elif derivative_order == 1:
                return eig_func_dz
            elif derivative_order == 2:
                return eig_func_ddz
            else:
                raise ValueError

        # find eigenvalues
        eig_frequencies = find_roots(char_eq, order, np.arange(0, 1e3, 1), -2, atol=1e-1)
        # print("eigenfrequencies:")

        # create eigen function vectors
        class SWMFunctionVector(ComposedFunctionVector):
            """
            String With Mass Function Vector, necessary due to manipulated scalar product
            """
            @property
            def func(self):
                return self.members["funcs"][0]

            @property
            def scalar(self):
                return self.members["scalars"][0]

        eig_vectors = []
        for n in range(order):
            eig_vectors.append(SWMFunctionVector(Function(phi_k_factory(eig_frequencies[n]),
                                                          derivative_handles=[phi_k_factory(eig_frequencies[n],
                                                                                            der_order)
                                                                              for der_order in range(1, 3)],
                                                          domain=spat_domain.bounds,
                                                          nonzero=spat_domain.bounds),
                                                 phi_k_factory(eig_frequencies[n])(0)))

        # normalize eigen-vectors
        norm_eig_vectors = [normalize_function(vec) for vec in eig_vectors]
        norm_eig_funcs = np.array([vec.func for vec in norm_eig_vectors])

        # debug print eigenfunctions
        if dump_data:
            func_vals = []
            for vec in eig_vectors:
                func_vals.append(np.vectorize(vec.func)(spat_domain))

            norm_func_vals = []
            for func in norm_eig_funcs:
                norm_func_vals.append(np.vectorize(func)(spat_domain))

            # dump eigenfunctions
            print("dumping eigenfunction data ..")
            with open("../results/swm_eigenfunctions.dat", "wb") as f:
                dump((spat_domain, (func_vals, norm_func_vals)), f)

            # dump char function
            freq_vals = np.arange(0, 1e2, 1e-3)
            char_data = np.vectorize(char_eq)(freq_vals)
            print("dumping char eq data ..")
            with open("../results/swm_char_eq.dat", "wb") as f:
                dump((freq_vals, (char_data, eig_frequencies)), f)

            if display_data:
                app = QApplication([])
                clrs = ["r", "g", "b", "c", "m", "y", "k", "w"]
                for n in range(1, order + 1, len(clrs)):
                    pw_phin_k = pg.plot(title="phin_k for k in [{0}, {1}]".format(n, min(n + len(clrs), order)))
                    for k in range(len(clrs)):
                        if k + n > order:
                            break
                        pw_phin_k.plot(x=spat_domain, y=norm_func_vals[n + k - 1], pen=clrs[k])

                app.exec_()
                del app

        return norm_eig_vectors, norm_eig_funcs
